﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using testjob;
namespace ConsoleApp1
{

    /*
     Впринципе могу дописать и/или переписать если будут замечания или уточнения.
     
     */
    class Program
    {
        
        static void Main(string[] args)
        {
            do
            {
                calculatethearea calculatethearea = new calculatethearea();
                calculatethearea.CallInCircle();
                try
                {
                    calculatethearea.CallInTriangle();
                }
                catch (AreaException e) //trycatch если пользователь ввел не правильный треугольник
                {
                    Console.WriteLine(e.Message);
                }
                Console.WriteLine("Press enter to repeat");
            } while (Console.ReadKey(true).Key == ConsoleKey.Enter);//повтор решения
        }
    }
}
