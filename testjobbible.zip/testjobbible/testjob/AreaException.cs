﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace testjob
{
   public class AreaException : ArgumentException
    {
        public AreaException()
        {
            
        }

        public AreaException(string message) : base(message)
        {
        }

        public AreaException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public AreaException(string message, string paramName) : base(message, paramName)
        {
        }

        public AreaException(string message, string paramName, Exception innerException) : base(message, paramName, innerException)
        {
        }

        protected AreaException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
        public override string ToString()
        {
            return base.ToString(); 
        }
    }
}
