﻿
using System;


namespace testjob
{
    public class calculatethearea
    {
        
        public double Circle(double r) //площадь круга
        {
            
            return Math.PI * r * r;
        }

        public double Triangle(double a, double b, double c) // площадь треугольника
        { 
           
 
            if (a + b < c || a + c < b || c + b < a)
                throw new AreaException("unncorect data");
           double p = (a + b + c) / 2;
           double s = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
           return s;
        }

        public void CallInCircle() //вызов
        {
            double _r;
            do
            {
                Console.WriteLine("input r");
            } while (!double.TryParse(Console.ReadLine(), out _r) || _r < 0);
            Console.WriteLine(Circle(_r));
        }

        public void CallInTriangle() // вызов
        {
            double _a;
            do 
            {
                Console.WriteLine("input a");
            } while (!double.TryParse(Console.ReadLine(), out _a) || _a < 0) ;
                double _b;
            do
            {
                Console.WriteLine("input b");
            } while (!double.TryParse(Console.ReadLine(), out _b) || _b < 0);
            double _c;
            do
            {
                Console.WriteLine("input c");
            } while (!double.TryParse(Console.ReadLine(), out _c) || _c < 0);
            Console.WriteLine(Triangle(_a, _b, _c));
            if (isrectangular(_a, _b, _c)) Console.WriteLine("Rectangular");
            else
                Console.WriteLine("Not Rectangular");
        }

    public    bool isrectangular(double a, double b, double c) // проверка на прямоугольный треугольник
        {
            
            if (a + b < c || a + c < b || c + b < a)
                throw new AreaException("unncorect data inpossible triangle");
           if((Math.Pow(a, 2) + Math.Pow(b, 2)) == Math.Pow(c, 2) || (Math.Pow(b, 2) + Math.Pow(c, 2)) == Math.Pow(a, 2) || (Math.Pow(a, 2) + Math.Pow(c, 2)) == Math.Pow(b, 2))
                return true;
            return false;
        }

    }
}
