﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using testjob;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        Сalculatethearea сalculatethearea = new Сalculatethearea();
        [TestMethod]
        public void TestMethod1()
        {
            double actual = сalculatethearea.Circle(10);// результат функции
            double expected = 100 * Math.PI;// реальное значение
            Assert.AreEqual(actual, expected, 0.001);

        }
        [TestMethod]
        public void TestMethod2()
        {
          

            double actual = сalculatethearea.Triangle(3, 4, 5); // результат функции
            double expected = 6; // реальное значение
            Assert.AreEqual(actual, expected, 0.001);
        }
        [TestMethod]
        public void TestMethod3()
        {
            bool actual = сalculatethearea.isrectangular(3, 4, 5);//результат
            bool expected = true; //значение
            Assert.AreEqual(actual, expected);
        }
        [TestMethod]
        public void TestMethod4()
        {
            bool actual = сalculatethearea.isrectangular(3, 4, 4);//результат
            bool expected = false;// реальное значение
            Assert.AreEqual(actual, expected);
        }



    }
}
